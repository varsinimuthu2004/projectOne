package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.model.Flight;
import com.deloitte.service.FlightService;

@Controller
public class HomeController {

    @Autowired
    private FlightService flightService;

    @GetMapping({"/", "/home"})
    public String home(
            @RequestParam(required = false) String source,
            @RequestParam(required = false) String destination,
            Model model) {

        if (source != null && !source.trim().isEmpty()
                && destination != null && !destination.trim().isEmpty()) {
            List<Flight> flights = flightService.searchFlights(source, destination);
            model.addAttribute("flights", flights);
            model.addAttribute("searchedSource", source);
            model.addAttribute("searchedDestination", destination);
            model.addAttribute("hasSearched", true);
        }

        return "home";
    }
}
