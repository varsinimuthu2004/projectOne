package com.deloitte.controller;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.model.User;
import com.deloitte.service.UserService;
@Controller
@RequestMapping("/user")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	private UserService userService;
	@GetMapping("/signup")
	public String signupPage(Model model) {
		logger.info("Accessing Sign-Up page");
		model.addAttribute("signUpDto", new SignUpDto());
		return "signup";
	}
	@PostMapping("/signup")
	public String processSignup(@Valid @ModelAttribute("signUpDto") SignUpDto signUpDto,
			BindingResult bindingResult, Model model) {
		logger.info("Received signup request for: {}", signUpDto.getEmail());
		// 1. Form Validation using BindingResult and @Valid annotations
		if (bindingResult.hasErrors()) {
			String firstError = bindingResult.getFieldError().getDefaultMessage();
			logger.warn("Form validation failed on signup: {}", firstError);
			model.addAttribute("errorMsg", firstError);
			model.addAttribute("signUpDto", signUpDto);
			return "signup";
		}
		// 2. Call service layer (throws custom EmailAlreadyExistsException if email exists)
		int result = userService.signup(signUpDto);
		if (result == 1) {
			logger.info("User registered successfully: {}", signUpDto.getEmail());
			model.addAttribute("successMsg", "Sign Up successful! Please login with your credentials.");
			model.addAttribute("loginDto", new LoginDto(signUpDto.getEmail(), ""));
			return "login";
		} else if (result == -2) {
			model.addAttribute("errorMsg", "Password must be greater than 8 characters.");
			model.addAttribute("signUpDto", signUpDto);
			return "signup";
		} else {
			model.addAttribute("errorMsg", "Registration failed. Please verify your details.");
			model.addAttribute("signUpDto", signUpDto);
			return "signup";
		}
	}
	@GetMapping("/login")
	public String loginPage(@RequestParam(required = false) String redirect, Model model) {
		logger.info("Accessing Login page");
		model.addAttribute("loginDto", new LoginDto());
		return "login";
	}
	@PostMapping("/login")
	public String processLogin(@Valid @ModelAttribute("loginDto") LoginDto loginDto,
			BindingResult bindingResult, HttpSession session, Model model) {
		logger.info("Received login request for: {}", loginDto.getEmail());
		// Form Validation using BindingResult
		if (bindingResult.hasErrors()) {
			String firstError = bindingResult.getFieldError().getDefaultMessage();
			logger.warn("Form validation failed on login: {}", firstError);
			model.addAttribute("errorMsg", firstError);
			model.addAttribute("loginDto", loginDto);
			return "login";
		}
		User user = userService.login(loginDto);
		if (user != null) {
			logger.info("User {} logged in successfully as {}", user.getEmail(), user.getRole());
			session.setAttribute("user", user);
			// Check if there was a redirected flight booking attempt
			Long redirectFlightId = (Long) session.getAttribute("redirectFlightId");
			if (redirectFlightId != null) {
				session.removeAttribute("redirectFlightId");
				return "redirect:/booking/form?flightId=" + redirectFlightId;
			}
			if ("admin".equalsIgnoreCase(user.getRole())) {
				return "redirect:/admin/dashboard";
			} else {
				return "redirect:/user/dashboard";
			}
		} else {
			logger.warn("Authentication failed for: {}", loginDto.getEmail());
			model.addAttribute("errorMsg", "Invalid email or password. Please try again.");
			model.addAttribute("loginDto", loginDto);
			return "login";
		}
	}
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		User user = (User) session.getAttribute("user");
		if (user != null) {
			logger.info("User logged out: {}", user.getEmail());
		}
		session.invalidate();
		return "redirect:/user/login";
	}
	@GetMapping("/dashboard")
	public String dashboard(HttpSession session, Model model) {
		User user = (User) session.getAttribute("user");
		if (user == null) {
			logger.warn("Unauthorized access to user dashboard. Redirecting to login.");
			return "redirect:/user/login";
		}
		model.addAttribute("user", user);
		return "user-dashboard";
	}
	@GetMapping("/profile")
	public String profile(HttpSession session, Model model) {
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return "redirect:/user/login";
		}
		model.addAttribute("user", user);
		return "profile";
	}
	@PostMapping("/profile")
	public String updateProfile(@RequestParam String newPassword, HttpSession session, Model model) {
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return "redirect:/user/login";
		}
		if (newPassword == null || newPassword.trim().length() <= 8) {
			logger.warn("Profile update failed: password length <= 8 for user {}", user.getEmail());
			model.addAttribute("errorMsg", "Password must be greater than 8 characters.");
			model.addAttribute("user", user);
			return "profile";
		}
		boolean ok = userService.updatePassword(user.getUserId(), newPassword);
		if (ok) {
			logger.info("Password updated successfully for user ID {}", user.getUserId());
			user.setPassword(newPassword.trim());
			session.setAttribute("user", user);
			model.addAttribute("successMsg", "Password updated successfully!");
		} else {
			logger.error("Failed to update password in database for user ID {}", user.getUserId());
			model.addAttribute("errorMsg", "Failed to update password.");
		}
		model.addAttribute("user", user);
		return "profile";
	}
}

