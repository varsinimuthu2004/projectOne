package com.deloitte.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class SignUpDto {
	
	@NotNull(message = "Email is required")
	@Size(min = 5, max = 100, message = "Email must be between 5 and 100 characters")
	@Email(message = "Please enter a valid email format (e.g. user@example.com)")
	private String email;
	@NotNull(message = "Password is required")
	@Size(min = 9, message = "Password must be greater than 8 characters")
	private String password;
	@NotNull(message = "Role is required")
	@Size(min = 4, max = 5, message = "Role must be 'user' or 'admin'")
	private String role; // 'user' or 'admin'

	public SignUpDto() {
	}

	public SignUpDto(String email, String password, String role) {
		this.email = email;
		this.password = password;
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "SignUpDto [email=" + email + ", role=" + role + "]";
	}
}
