package com.deloitte.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PassengerDto {

	@NotNull(message = "Passenger name is required")
	@Size(min = 2, max = 50, message = "Passenger name must be between 2 and 50 characters")
	private String passengerName;
	@NotNull(message = "Age is required")
	private Integer age;
	@NotNull(message = "Gender is required")
	@Size(min = 4, max = 6, message = "Gender must be selected (male, female, other)")
	private String gender; // 'male', 'female', 'other'

	public PassengerDto() {
	}

	public PassengerDto(String passengerName, Integer age, String gender) {
		this.passengerName = passengerName;
		this.age = age;
		this.gender = gender;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "PassengerDto [passengerName=" + passengerName + ", age=" + age + ", gender=" + gender + "]";
	}
}
