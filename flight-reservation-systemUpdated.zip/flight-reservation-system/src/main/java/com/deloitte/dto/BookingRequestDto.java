package com.deloitte.dto;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
public class BookingRequestDto {
	@NotNull(message = "Flight ID is required")
	private Long flightId;
	@NotNull(message = "Journey date cannot be null")
	@Size(min = 10, max = 10, message = "Journey date must be in YYYY-MM-DD format")
	private String journeyDate;
	@NotNull(message = "Number of passengers is required")
	private Integer numberOfPassengers;
	// Server-side validation of nested object using @Valid
	@Valid
	@NotNull(message = "Lead passenger details cannot be null")
	private PassengerDto leadPassenger;
	public BookingRequestDto() {
	}
	public BookingRequestDto(Long flightId, String journeyDate, Integer numberOfPassengers,
			PassengerDto leadPassenger) {
		this.flightId = flightId;
		this.journeyDate = journeyDate;
		this.numberOfPassengers = numberOfPassengers;
		this.leadPassenger = leadPassenger;
	}
	public Long getFlightId() {
		return flightId;
	}
	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}
	public String getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}
	public Integer getNumberOfPassengers() {
		return numberOfPassengers;
	}
	public void setNumberOfPassengers(Integer numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}
	public PassengerDto getLeadPassenger() {
		return leadPassenger;
	}
	public void setLeadPassenger(PassengerDto leadPassenger) {
		this.leadPassenger = leadPassenger;
	}
	@Override
	public String toString() {
		return "BookingRequestDto [flightId=" + flightId + ", journeyDate=" + journeyDate + ", numberOfPassengers="
				+ numberOfPassengers + ", leadPassenger=" + leadPassenger + "]";
	}
}