package com.deloitte.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class LoginDto {

	@NotNull(message = "Email is required")
	@Size(min = 5, max = 100, message = "Email length must be between 5 and 100 characters")
	@Email(message = "Please enter a valid email format")
	private String email;
	@NotNull(message = "Password is required")
	@Size(min = 1, message = "Password cannot be empty")
	private String password;

	public LoginDto() {
	}

	public LoginDto(String email, String password) {
		this.email = email;
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "LoginDto [email=" + email + "]";
	}
}
