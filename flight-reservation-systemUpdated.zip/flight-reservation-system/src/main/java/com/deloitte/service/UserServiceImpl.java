package com.deloitte.service;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.deloitte.dao.UserDao;
import com.deloitte.dto.LoginDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.exception.EmailAlreadyExistsException;
import com.deloitte.model.User;
@Service
public class UserServiceImpl implements UserService {
	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	@Autowired
	private UserDao userDao;
	public UserServiceImpl() {
	}
	@Autowired
	public UserServiceImpl(UserDao userDao) {
		this.userDao = userDao;
	}
	@Override
	public int signup(SignUpDto signUpDto) {
		if (signUpDto == null || signUpDto.getEmail() == null || signUpDto.getPassword() == null
				|| signUpDto.getRole() == null) {
			logger.warn("Signup attempt with null or incomplete details.");
			return 0;
		}
		String email = signUpDto.getEmail().trim();
		String password = signUpDto.getPassword().trim();
		String role = signUpDto.getRole().trim().toLowerCase();
		logger.info("Attempting to register user with email: {}", email);
		if (email.isEmpty() || !email.contains("@")) {
			logger.warn("Invalid email format for: {}", email);
			return 0;
		}
		if (password.length() <= 8) {
			logger.warn("Password too short for user: {}", email);
			return -2; // Password too short
		}
		// Business Exception: Check if email already exists in database
		User existing = userDao.getUserByEmail(email);
		if (existing != null) {
			logger.warn("Email already exists in database: {}", email);
			throw new EmailAlreadyExistsException("The email '" + email + "' is already registered. Please login or use a different email.");
		}
		signUpDto.setEmail(email);
		signUpDto.setPassword(password);
		signUpDto.setRole(role);
		int rows = userDao.insertUser(signUpDto);
		logger.info("User registered successfully. Rows affected: {}", rows);
		return rows;
	}
	@Override
	public User login(LoginDto loginDto) {
		if (loginDto == null || loginDto.getEmail() == null || loginDto.getPassword() == null) {
			logger.warn("Login attempt with null credentials.");
			return null;
		}
		String email = loginDto.getEmail().trim();
		String password = loginDto.getPassword().trim();
		logger.info("Attempting login for user: {}", email);
		if (email.isEmpty() || password.isEmpty()) {
			return null;
		}
		User user = userDao.getUserByEmailAndPassword(email, password);
		if (user != null) {
			logger.info("Login successful for user: {} with role: {}", email, user.getRole());
		} else {
			logger.warn("Login failed for user: {}. Invalid email or password.", email);
		}
		return user;
	}
	@Override
	public User getUserByEmail(String email) {
		if (email == null) {
			return null;
		}
		return userDao.getUserByEmail(email.trim());
	}
	@Override
	public User getUserById(long userId) {
		return userDao.getUserById(userId);
	}
	@Override
	public boolean updatePassword(long userId, String newPassword) {
		if (newPassword == null || newPassword.trim().length() <= 8) {
			logger.warn("Password update rejected: new password must be greater than 8 characters.");
			return false;
		}
		logger.info("Updating password for user ID: {}", userId);
		return userDao.updatePassword(userId, newPassword.trim()) == 1;
	}
	@Override
	public List<User> getAllUsers() {
		return userDao.getAllUsers();
	}
}










/*
 * package com.deloitte.service;
 * 
 * import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Service;
 * 
 * import com.deloitte.dao.UserDao; import com.deloitte.dto.LoginDto; import
 * com.deloitte.dto.SignUpDto; import com.deloitte.model.User;
 * 
 * @Service public class UserServiceImpl implements UserService {
 * 
 * @Autowired private UserDao userDao;
 * 
 * public UserServiceImpl() { }
 * 
 * @Autowired public UserServiceImpl(UserDao userDao) { this.userDao = userDao;
 * }
 * 
 * @Override public int signup(SignUpDto signUpDto) { if (signUpDto == null ||
 * signUpDto.getEmail() == null || signUpDto.getPassword() == null ||
 * signUpDto.getRole() == null) { return 0; }
 * 
 * String email = signUpDto.getEmail().trim(); String password =
 * signUpDto.getPassword().trim(); String role =
 * signUpDto.getRole().trim().toLowerCase();
 * 
 * if (email.isEmpty() || !email.contains("@")) { return 0; }
 * 
 * if (password.length() <= 8) { return -2; // Password too short (must be > 8
 * characters) }
 * 
 * if (!role.equals("user") && !role.equals("admin")) { return 0; }
 * 
 * // Check if email already exists User existing =
 * userDao.getUserByEmail(email); if (existing != null) { return -1; //
 * Duplicate email }
 * 
 * signUpDto.setEmail(email); signUpDto.setPassword(password);
 * signUpDto.setRole(role);
 * 
 * return userDao.insertUser(signUpDto); }
 * 
 * @Override public User login(LoginDto loginDto) { if (loginDto == null ||
 * loginDto.getEmail() == null || loginDto.getPassword() == null) { return null;
 * } String email = loginDto.getEmail().trim(); String password =
 * loginDto.getPassword().trim();
 * 
 * if (email.isEmpty() || password.isEmpty()) { return null; }
 * 
 * return userDao.getUserByEmailAndPassword(email, password); }
 * 
 * @Override public User getUserByEmail(String email) { if (email == null) {
 * return null; } return userDao.getUserByEmail(email.trim()); }
 * 
 * @Override public User getUserById(long userId) { return
 * userDao.getUserById(userId); }
 * 
 * @Override public boolean updatePassword(long userId, String newPassword) { if
 * (newPassword == null || newPassword.trim().length() <= 8) { return false; }
 * return userDao.updatePassword(userId, newPassword.trim()) == 1; }
 * 
 * @Override public List<User> getAllUsers() { return userDao.getAllUsers(); } }
 */