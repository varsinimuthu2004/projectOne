package com.deloitte.exception;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
@ControllerAdvice
public class GlobalExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	// 1. Business Exception: Email Already Registered
	@ExceptionHandler(EmailAlreadyExistsException.class)
	public String handleEmailAlreadyExists(EmailAlreadyExistsException ex, Model model) {
		logger.warn("Business Exception - Email already exists: {}", ex.getMessage());
		model.addAttribute("errorMessage", ex.getMessage());
		return "error";
	}
	// 2. Business Exception: Insufficient Seats Available
	@ExceptionHandler(SeatNotAvailableException.class)
	public String handleSeatNotAvailable(SeatNotAvailableException ex, Model model) {
		logger.warn("Business Exception - Seat unavailable: {}", ex.getMessage());
		model.addAttribute("errorMessage", ex.getMessage());
		return "error";
	}
	// 3. Business Exception: Flight Not Found
	@ExceptionHandler(FlightNotFoundException.class)
	public String handleFlightNotFound(FlightNotFoundException ex, Model model) {
		logger.warn("Business Exception - Flight not found: {}", ex.getMessage());
		model.addAttribute("errorMessage", ex.getMessage());
		return "error";
	}
	// 4. Technical / General Exception: System, SQL, or Unexpected Runtime Errors
	@ExceptionHandler(Exception.class)
	public String handleGeneralException(Exception ex, Model model) {
		logger.error("Technical Exception caught by GlobalExceptionHandler: ", ex);
		model.addAttribute("errorMessage",
				ex.getMessage() != null ? ex.getMessage() : "An unexpected server error occurred. Please try again.");
		return "error";
	}
}