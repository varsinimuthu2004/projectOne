package com.deloitte.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.Before;
import org.junit.Test;
import com.deloitte.dao.UserDao;
import com.deloitte.dto.BookingRequestDto;
import com.deloitte.dto.LoginDto;
import com.deloitte.dto.PassengerDto;
import com.deloitte.dto.SignUpDto;
import com.deloitte.exception.EmailAlreadyExistsException;
import com.deloitte.model.User;
import com.deloitte.service.UserService;
import com.deloitte.service.UserServiceImpl;
public class UserServiceTest {
	private UserService userService;
	private FakeUserDao fakeUserDao;
	private Validator validator;
	// In-memory fake DAO for clean, isolated, fast unit testing without live DB
	static class FakeUserDao implements UserDao {
		private List<User> db = new ArrayList<>();
		private long nextId = 1001L;
		@Override
		public int insertUser(SignUpDto dto) {
			User u = new User(nextId++, dto.getEmail(), dto.getPassword(), dto.getRole());
			db.add(u);
			return 1;
		}
		@Override
		public User getUserByEmailAndPassword(String email, String password) {
			for (User u : db) {
				if (u.getEmail().equalsIgnoreCase(email) && u.getPassword().equals(password)) {
					return u;
				}
			}
			return null;
		}
		@Override
		public User getUserByEmail(String email) {
			for (User u : db) {
				if (u.getEmail().equalsIgnoreCase(email)) {
					return u;
				}
			}
			return null;
		}
		@Override
		public User getUserById(long userId) {
			for (User u : db) {
				if (u.getUserId() == userId) {
					return u;
				}
			}
			return null;
		}
		@Override
		public int updatePassword(long userId, String newPassword) {
			User u = getUserById(userId);
			if (u != null) {
				u.setPassword(newPassword);
				return 1;
			}
			return 0;
		}
		@Override
		public List<User> getAllUsers() {
			return new ArrayList<>(db);
		}
	}
	@Before
	public void setUp() {
		fakeUserDao = new FakeUserDao();
		userService = new UserServiceImpl(fakeUserDao);
		// Seed a known test user
		SignUpDto existingUser = new SignUpDto("test.user@flightapp.com", "SecurePass@2026", "user");
		fakeUserDao.insertUser(existingUser);
		// Initialize Bean Validator
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
	}
	// 1. Test Signup Success
	@Test
	public void testSignupSuccess() {
		SignUpDto newDto = new SignUpDto("new.user@flightapp.com", "Password@1234", "user");
		int result = userService.signup(newDto);
		assertEquals(1, result);
		User saved = userService.getUserByEmail("new.user@flightapp.com");
		assertNotNull(saved);
		assertEquals("user", saved.getRole());
	}
	// 2. Test Signup Fails When Password Too Short
	@Test
	public void testSignupFailsWhenPasswordTooShort() {
		SignUpDto shortPassDto = new SignUpDto("short@flightapp.com", "12345678", "user");
		int result = userService.signup(shortPassDto);
		assertEquals(-2, result);
	}
	// 3. Test Custom Business Exception: EmailAlreadyExistsException
	@Test(expected = EmailAlreadyExistsException.class)
	public void testSignupThrowsEmailAlreadyExistsException() {
		SignUpDto duplicateDto = new SignUpDto("test.user@flightapp.com", "AnotherPass@2026", "user");
		userService.signup(duplicateDto);
	}
	// 4. Test Login Success
	@Test
	public void testLoginSuccess() {
		LoginDto loginDto = new LoginDto("test.user@flightapp.com", "SecurePass@2026");
		User loggedIn = userService.login(loginDto);
		assertNotNull(loggedIn);
		assertEquals("test.user@flightapp.com", loggedIn.getEmail());
	}
	// 5. Test Login Failure
	@Test
	public void testLoginFailureInvalidPassword() {
		LoginDto loginDto = new LoginDto("test.user@flightapp.com", "WrongPassword");
		User loggedIn = userService.login(loginDto);
		assertNull(loggedIn);
	}
	// 6. Test Validating Nested Objects (@Valid on leadPassenger)
	@Test
	public void testNestedObjectValidationSuccess() {
		PassengerDto passenger = new PassengerDto("John Doe", 30, "male");
		BookingRequestDto bookingRequest = new BookingRequestDto(5001L, "2026-11-20", 1, passenger);
		Set<ConstraintViolation<BookingRequestDto>> violations = validator.validate(bookingRequest);
		assertTrue("Expected no validation violations", violations.isEmpty());
	}
	@Test
	public void testNestedObjectValidationFailsWhenPassengerNameIsBlank() {
		// Passenger name length < 2 violates @Size(min = 2, max = 50)
		PassengerDto invalidPassenger = new PassengerDto("A", 30, "male");
		BookingRequestDto bookingRequest = new BookingRequestDto(5001L, "2026-11-20", 1, invalidPassenger);
		Set<ConstraintViolation<BookingRequestDto>> violations = validator.validate(bookingRequest);
		assertEquals(1, violations.size());
		ConstraintViolation<BookingRequestDto> violation = violations.iterator().next();
		assertEquals("leadPassenger.passengerName", violation.getPropertyPath().toString());
	}
}